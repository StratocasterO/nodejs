import UsersController from './users';

export default function (app) {
  app.use(UsersController);
}
