export default {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'amor',
    connectionLimit: 10,
    forceCleanDatabase: true
};